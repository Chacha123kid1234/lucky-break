import { io } from 'socket.io-client';
import { BRAND,VERSION } from '../shared/config.js';
import { movePlayer,obstacles } from '../shared/physics.js';
import { money } from '../shared/money.js';
import { t,escape } from './i18n.js';
import { World } from './world.js';
import { UI } from './ui.js';
import { AudioManager } from './audio.js';
import { VoiceChat } from './voice.js';
import { loadSettings,saveSettings,preset } from './settings.js';
class Game {
 constructor(){this.settings=loadSettings();saveSettings(this.settings);this.keys=new Set();this.intent={};this.seq=0;this.offset=0;this.ping=0;this.messages=0;this.frames=0;this.networkAt=0;this.yaw=0;this.pitch=0;this.crouch=false;this.state=null;this.local=null;this.profile=null;this.slots=[];this.effectIds=new Set();this.started=false;this.suppressLock=false;this.lastHud=0;this.lastVoice=0;this.frameAt=0;this.fps=0;this.lastPerf=0;this.target=null;this.audio=new AudioManager(this.settings);}
 get me(){return this.state?.players.find(p=>p.id===this.playerId);}
 toast(key,args={},raw=false){const n=document.createElement('div');n.className='toast';n.textContent=raw?key:t(key,args);document.querySelector('#toasts').append(n);setTimeout(()=>n.remove(),6000);}
 banner(key){document.querySelector('#banner').textContent=t(key);clearTimeout(this.bannerTimeout);this.bannerTimeout=setTimeout(()=>document.querySelector('#banner').textContent='',3800);}
 async start(){document.title=BRAND.title;document.querySelector('#loading-title').textContent=BRAND.title;document.querySelector('#loading-label').textContent=t('loading');document.querySelector('#loading-tip').textContent=t('tip.0');document.querySelector('#chat-input input').placeholder=t('textChat');
  try{this.runtime=await fetch('/runtime-config').then(r=>r.json());this.world=new World(document.querySelector('#world'),this.settings);}catch(e){console.error(e);this.toast('unsupported');document.querySelector('#loading-label').textContent=t('unsupported');return;}
  this.socket=io({reconnection:true,reconnectionAttempts:Infinity});this.ui=new UI(this);this.voice=new VoiceChat(this.socket,this.audio,this.settings,this.runtime,key=>this.toast(key));this.bind();
  this.socket.on('connect_error',()=>{const label=document.querySelector('#loading-label');if(label)label.textContent=t('reconnecting');});
  this.socket.on('state',s=>this.onState(s));this.socket.on('effects',es=>es.forEach(e=>this.onEffect(e)));this.socket.on('disconnect',()=>{if(this.state){this.toast('disconnected');this.banner('reconnecting');}});
  this.socket.on('connect',async()=>{if(!this.started)return;try{await this.hello();const code=localStorage.getItem('room');if(code)await this.join(code,this.profile.name,true);}catch(e){this.toast('error.'+e.message);}});
  await new Promise(resolve=>this.socket.connected?resolve():this.socket.once('connect',resolve));await this.hello();this.started=true;
  this.ui.show('main');document.querySelector('#loading .progress i').style.width='100%';document.querySelector('#loading').style.opacity='0';setTimeout(()=>document.querySelector('#loading').remove(),450);
  const invite=new URL(location.href).searchParams.get('room')||localStorage.getItem('room');if(invite)await this.join(invite,this.profile.name,true);
  if(innerWidth<700)this.toast('mobile');if(this.runtime.dev)window.__game=this;
  requestAnimationFrame(now=>this.frame(now));setInterval(async()=>{if(!this.socket.connected)return;const start=Date.now();try{const reply=await this.request('ping',{});this.ping=Date.now()-start;this.offset=reply.time-(start+Date.now())/2;}catch{}},3000);
 }
 request(event,payload){return new Promise((resolve,reject)=>{this.socket.timeout(8000).emit(event,payload,(err,result)=>{if(err)reject(Error('SERVER_ERROR'));else if(!result?.ok)reject(Error(result?.error||'SERVER_ERROR'));else resolve(result);});});}
 async hello(){const data=await this.request('hello',{version:VERSION,token:localStorage.getItem('profileToken')});this.profile=data.profile;this.slots=data.slots;localStorage.setItem('profileToken',data.profile.token);return data;}
 async syncProfile(){try{const data=await this.request('sync',{});this.profile=data.profile;if(data.state)this.onState(data.state);}catch{}}
 async host(slot,rules){try{await this.audio.start();const response=await this.request('host',{slot,rules,name:this.playerName||this.profile.name});this.playerId=response.playerId;this.onState(response.state);localStorage.setItem('room',response.state.code);this.ui.show('lobby');}catch(e){this.toast('error.'+e.message);}}
 async join(code,name,reconnect=false){try{const response=await this.request('join',{code:code.toUpperCase(),name:name||this.profile.name});this.playerId=response.playerId;this.local=null;this.onState(response.state);localStorage.setItem('room',response.state.code);if(!['TRAVELLING','DAY_RESULTS','ENDING','GAME_OVER'].includes(response.state.state))this.ui.show('lobby');if(!reconnect)await this.audio.start();}catch(e){this.toast('error.'+e.message);if(e.message==='ROOM_NOT_FOUND'){localStorage.removeItem('room');this.ui.show('main');}}}
 async action(type,payload={},id=crypto.randomUUID()){try{return await this.request('action',{id,type,payload});}catch(e){this.toast('error.'+e.message);return {ok:false,error:e.message};}}
 async leave(){try{await this.request('leave',{});}catch{}this.voice.stop();this.state=null;this.local=null;this.playerId=null;localStorage.removeItem('room');await this.hello();this.world.floorKey='';this.world.buildHub();for(const av of this.world.avatars.values())this.world.scene.remove(av.mesh);this.world.avatars.clear();this.ui.show('main');document.querySelector('#hud').hidden=true;document.querySelector('#chat-log').innerHTML='';document.querySelector('#body-vision').style.background='none';}
 onState(s){this.messages++;const oldState=this.state?.state,oldEpoch=this.state?.epoch;this.state=s;this.world.serverOffset=this.offset;this.world.setState(s,this.playerId);this.voice.sync(s,this.playerId);const me=this.me;if(!me)return;
  if(!this.local||oldEpoch!==s.epoch||oldState!==s.state){this.local=structuredClone(me);this.yaw=me.yaw||0;this.pitch=me.pitch||0;}
  else{const dx=me.x-this.local.x,dz=me.z-this.local.z,d=Math.hypot(dx,dz);if(d>2){this.local.x=me.x;this.local.z=me.z;}else if(d>.03){this.local.x+=dx*.2;this.local.z+=dz*.2;}this.local.y+=(me.y-this.local.y)*.25;this.local.body=me.body;this.local.buffs=me.buffs;this.local.held=me.held;}
  if(oldState!==s.state){this.keys.clear();this.intent={};const panels={LOBBY:'lobby',TRAVELLING:'travel',DAY_RESULTS:'results',ENDING:'ending',GAME_OVER:'gameover'};if(panels[s.state])this.ui.show(panels[s.state]);else if(s.state==='CASINO'||s.state==='INTERMISSION'){this.ui.panel='';this.ui.root.innerHTML='';this.unlock();this.toast('enter');}}
 }
 onEffect(e){if(this.effectIds.has(e.id))return;this.effectIds.add(e.id);if(this.effectIds.size>500)this.effectIds.delete(this.effectIds.values().next().value);this.world.effect(e);this.audio.sound(e.type);
  if(e.type==='quota')this.banner('quotaCleared');if(e.type==='win'&&e.multiplier>=10){this.banner('bigWin');this.audio.sound('jackpot');}if(e.type==='basket')this.banner('basketScore');if(e.type==='achievement'&&e.player===this.playerId){if(!this.profile.achievements.includes(e.achievement))this.profile.achievements.push(e.achievement);const toast=document.createElement('div');toast.className='toast';toast.innerHTML=`<small>${escape(t('achievementUnlocked'))}</small><b>✦ ${escape(t('achievement.'+e.achievement))}</b>`;document.querySelector('#toasts').append(toast);setTimeout(()=>toast.remove(),7000);}if(['win','loss','push'].includes(e.type)&&e.player===this.playerId)this.toast((BigInt(e.profit)>=0n?'+':'')+money(e.profit),{},true);if(e.type==='secret'&&e.player===this.playerId)this.toast('secretFound');if(this.settings.subtitles&&['quota','item','body','bounce','elevator','bet','win','loss','basket'].includes(e.type)){document.querySelector('#subtitles').textContent='♪ '+t(e.type==='body'?'trade':e.type==='bounce'?'prop.basketball':e.type==='item'?'use':e.type==='elevator'?'elevator':e.type==='basket'?'basketScore':e.type==='quota'?'quotaCleared':e.type);clearTimeout(this.subtitleTimeout);this.subtitleTimeout=setTimeout(()=>document.querySelector('#subtitles').textContent='',2000);}
 }
 lock(){if(!this.state||this.ui.panel)return;this.audio.start();const result=document.querySelector('#world').requestPointerLock();result?.catch(()=>{});document.querySelector('#crosshair').hidden=false;}
 unlock(){this.suppressLock=true;document.exitPointerLock();this.keys.clear();this.intent={};setTimeout(()=>this.suppressLock=false,100);}
 async use(){const target=this.world.lookTarget(),table=this.ui.panel==='table'?this.ui.data.id:target?.type==='table'?target.id:undefined;await this.action('use',{target:target?.type==='player'?target.id:undefined,tableId:table});}
 interact(){const target=this.world.lookTarget();if(!target)return;if(target.type==='prop'){this.action('pickup',{id:target.id});return;}if(target.type==='player'){this.use();return;}if(target.type==='table'){this.ui.show('table',{id:target.id});return;}if(target.type==='secret'){this.action('secret',{id:target.id});return;}const pages={shuttle:'shuttle',items:'items',cosmetics:'cosmetics',clinic:'clinic',exchange:'exchange',challenge:'challenge',tickets:'tickets',arcade:'arcade',photo:'photo',stats:'stats',elevator:'elevator',vending:'vending',poster:'poster'};if(pages[target.type])this.ui.show(pages[target.type]);}
 setSetting(key,value){if(key==='quality')preset(this.settings,value);else this.settings[key]=value;if(key==='textures')this.settings.textures=value?1:0;saveSettings(this.settings);this.audio.apply();this.world.applySettings(this.settings);if(key==='textures'||key==='quality'){this.world.floorKey='';if(!this.state)this.world.buildHub();}}
 async loadDevices(){this.devices=await this.voice.devices();if(this.ui.panel==='settings'&&this.ui.settingsTab==='audio')this.ui.render();}
 bind(){
  document.querySelector('#world').addEventListener('click',()=>this.lock());
  document.addEventListener('pointerlockchange',()=>{if(!document.pointerLockElement&&this.state&&!this.ui.panel&&!this.suppressLock)this.ui.show('pause');});
  document.addEventListener('mousemove',ev=>{if(document.pointerLockElement||this.ui.panel==='travel'){this.yaw-=ev.movementX*.002*this.settings.sensitivity;this.pitch=Math.max(-1.4,Math.min(1.4,this.pitch-ev.movementY*.002*this.settings.sensitivity));}});
  document.addEventListener('keydown',ev=>{
   if(this.rebinding){ev.preventDefault();this.settings.bindings[this.rebinding]=ev.code;this.rebinding=null;saveSettings(this.settings);this.ui.render();return;}
   const focus=document.activeElement,typing=focus?.matches('input,textarea,select');if(typing){if(ev.code==='Escape'){focus.blur();document.querySelector('#chat-input').hidden=true;}return;}
   const bindings=this.settings.bindings,k=ev.code;if(k==='Escape'){ev.preventDefault();if(this.ui.panel)this.ui.close();else this.ui.show('pause');return;}
   if(k==='Backquote'&&this.runtime.dev){ev.preventDefault();this.ui.show('console');setTimeout(()=>document.querySelector('#command')?.focus(),50);return;}
   if(this.state&&k===bindings.voice){ev.preventDefault();this.voice.pushing=true;if(!this.voice.allowed)this.toast('voiceEnable');return;}
   if(this.state&&(k===bindings.chat||k==='Enter'&&!this.ui.panel)){ev.preventDefault();this.unlock();const chat=document.querySelector('#chat-input');chat.hidden=false;chat.querySelector('input').focus();return;}
   if(this.ui.panel==='travel'&&k===bindings.emote){ev.preventDefault();this.ui.show('emotes');return;}
   if(this.ui.panel==='table'){if(/^Digit\d$/.test(k)){ev.preventDefault();this.ui.stake=(this.ui.stake==='0'?'':this.ui.stake)+k.at(-1);this.ui.render();}else if(k==='Backspace'){ev.preventDefault();this.ui.stake=this.ui.stake.slice(0,-1)||'0';this.ui.render();}else if(k==='Enter')this.ui.click('bet',{dataset:{}});return;}
   if(this.ui.panel||!this.state)return;
   if(Object.values(bindings).includes(k)||k==='Enter')ev.preventDefault();this.keys.add(k);if(ev.repeat)return;
   if(k===bindings.interact)this.interact();else if(k===bindings.use)this.use();else if(k===bindings.drop)this.action('drop');else if(k===bindings.ping){const target=this.world.lookTarget(),v=target?.point||this.world.camera.getWorldDirection(new (this.world.camera.position.constructor)()).multiplyScalar(8).add(this.world.camera.position);this.action('ping',{position:{x:v.x,y:v.y,z:v.z},kind:target?.type==='table'?'GAME':target?.type==='prop'?'ITEM':'LOOK'});}
   else if(k===bindings.overlay)this.ui.show('players');else if(k===bindings.emote){this.ui.show('emotes');}else if(k===bindings.chat||k==='Enter'){this.unlock();const chat=document.querySelector('#chat-input');chat.hidden=false;chat.querySelector('input').focus();}else if(k===bindings.crouch&&this.settings.crouchToggle)this.crouch=!this.crouch;else if(k===bindings.voice){this.voice.pushing=true;if(!this.voice.allowed)this.toast('voiceEnable');}
  });
  document.addEventListener('keyup',ev=>{this.keys.delete(ev.code);if(ev.code===this.settings.bindings.voice)this.voice.pushing=false;if(ev.code===this.settings.bindings.overlay&&this.ui.panel==='players')this.ui.close();});
  window.addEventListener('blur',()=>{this.keys.clear();this.intent={};this.voice.pushing=false;});
  document.querySelector('#chat-input').addEventListener('submit',async ev=>{ev.preventDefault();const input=ev.target.querySelector('input');if(input.value.trim())try{await this.request('chat',{text:input.value});}catch(e){this.toast('error.'+e.message);}input.value='';ev.target.hidden=true;this.lock();});
 }
 input(){const b=this.settings.bindings,paused=!!this.ui.panel||document.activeElement?.matches('input,textarea,select');return {seq:++this.seq,yaw:this.yaw,pitch:this.pitch,...Object.fromEntries(['forward','back','left','right','jump','sprint','crouch'].map(k=>[k,!paused&&(k==='crouch'&&this.settings.crouchToggle?this.crouch:this.keys.has(b[k]))])),...this.intent};}
 frame(now){requestAnimationFrame(t=>this.frame(t));const elapsed=now-this.frameAt;if(elapsed<1000/this.settings.fps-.5)return;this.frameAt=now;const dt=Math.min(.05,elapsed/1000||.016);this.frames++;
  if(this.local&&this.state){const input=this.input(),zone=this.state.state==='CASINO'?'casino':'hub';if(!['TRAVELLING','DAY_RESULTS','ENDING','GAME_OVER'].includes(this.state.state))movePlayer(this.local,input,dt,obstacles(zone,this.state.tables),zone);if(now-this.networkAt>45){this.socket.emit('input',input);this.networkAt=now;}this.local.yaw=this.yaw;this.local.pitch=this.pitch;}
  this.world.render(dt,now,this.local,!this.state);this.audio.update(this.state,this.local,dt);if(now-this.lastVoice>100){this.voice.update();this.lastVoice=now;}
  if(this.state&&!this.ui.panel){const target=this.world.lookTarget();this.target=target;this.world.highlight(target);const node=document.querySelector('#interaction');node.hidden=!target;if(target)node.innerHTML=`<kbd>${escape(this.settings.bindings.interact.replace('Key',''))}</kbd>${escape(target.type==='player'?target.name:t(target.name))}${target.type==='prop'?' · '+escape(t('pickup')):''}`;document.querySelector('#crosshair').hidden=false;}else this.world.highlight(null);
  if(now-this.lastHud>150){this.ui.refresh();this.lastHud=now;}
  if(this.runtime.dev&&now-this.lastPerf>1000){this.fps=Math.round(this.frames*1000/(now-this.lastPerf));const info=this.world.renderer.info.render;document.querySelector('#performance').hidden=false;document.querySelector('#performance').textContent=`${this.fps} FPS · ${this.ping} ms · ${info.calls} draws · ${info.triangles} tris · ${this.messages} snapshots/s`;this.frames=0;this.messages=0;this.lastPerf=now;}
 }
}
const game=new Game();game.start().catch(error=>{console.error(error);game.toast('error.SERVER_ERROR');document.querySelector('#loading-label').textContent=t('error.SERVER_ERROR');});
