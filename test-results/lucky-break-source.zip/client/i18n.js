import en,{cosmetics,challenges,achievements} from './lang/en.js';
for(const [id,label] of Object.entries(cosmetics))en[`cosmetic.${id}`]=label;
for(const [id,[name,description]] of Object.entries(challenges)){en[`challenge.${id}`]=name;en[`challenge.${id}.desc`]=description;}
for(const [id,name] of Object.entries(achievements)){en[`achievement.${id}`]=name;en[`achievement.${id}.desc`]=en[`achievementDesc.${id}`]||name;}
export const availableLocales=['en','fr','de','es','it','pt','pl','tr','uk','ru','ja','ko','zh-CN'];
let language=en;
export async function setLocale(locale){if(locale==='en'){language=en;return;}try{const pack=await import(`./lang/${locale}.js`);language={...en,...pack.default};}catch{language=en;}}
export function t(key,args={}){return String(language[key]??language['error.generic']).replace(/\{(\w+)\}/g,(_,name)=>args[name]??'');}
export const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
